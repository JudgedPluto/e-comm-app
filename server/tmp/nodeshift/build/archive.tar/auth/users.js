let dbConnection = null;
(async function () {
  dbConnection = await require("../db/connection");
})();

module.exports.findLocalUser = async function (username, password, callback) {
  try {
    const sqlFindUser =
      "SELECT u.id, u.email, u.role, u.fname, u.lname, u.contact, u.picture_location, u.verify_status, p.password " +
      "FROM users u, users_password p, users_oauth o " +
      "WHERE o.username = ? AND o.provider = 'local' AND u.id = p.user_id AND u.id = o.user_id " +
      "LIMIT 1";

    let [rows] = await dbConnection.execute(sqlFindUser, [username]);

    if (rows && rows.length != 0 && rows[0].password == password) {
      let user = {
        id: rows[0].id,
        email: rows[0].email,
        role: rows[0].role,
        firstName: rows[0].fname,
        lastName: rows[0].lname,
        contact: rows[0].contact,
        pictuteLocation: rows[0].picture_location,
        verifyStatus: rows[0].verify_status,
      };
      callback(null, user);
    } else {
      callback(null);
    }
  } catch (error) {
    callback(error);
  }
};

module.exports.findOAuthUser = async function (
  profileData,
  provider,
  callback
) {
  let isTransactionBegun = false;
  try {
    const sqlFindUser =
      "SELECT u.id, u.email, u.role, u.fname, u.lname, u.contact, u.picture_location, u.verify_status " +
      "FROM users u, users_oauth o " +
      "WHERE o.username = ? AND o.provider = ? AND u.id = o.user_id " +
      "LIMIT 1";
    let [rows] = await dbConnection.execute(sqlFindUser, [
      profileData.id,
      provider,
    ]);

    if (rows && rows.length != 0) {
      let user = {
        id: rows[0].id,
        email: rows[0].email,
        role: rows[0].role,
        firstName: rows[0].fname,
        lastName: rows[0].lname,
        contact: rows[0].contact,
        pictuteLocation: rows[0].picture_location,
        verifyStatus: rows[0].verify_status,
      };
      callback(null, user);
    } else {
      await dbConnection.beginTransaction();
      isTransactionBegun = true;

      const sqlCreateUser =
        "INSERT INTO users (email, fname, lname, role, verify_status) " +
        "VALUES (?, ?, ?, 'user', 0)";
      let [rows] = await dbConnection.execute(sqlCreateUser, [
        profileData.emails[0].value,
        profileData.name.givenName,
        profileData.name.familyName,
      ]);
      let id = rows.insertId;

      const sqlAssignProvider =
        "INSERT INTO users_oauth (user_id, username, provider) " +
        "VALUES (?, ?, ?)";
      await dbConnection.query(sqlAssignProvider, [
        id,
        profileData.id,
        provider,
      ]);

      await dbConnection.commit();

      let user = {
        id: id,
        email: profileData.emails[0].value,
        role: "user",
        firstName: profileData.name.givenName,
        lastName: profileData.name.familyName,
        contact: null,
        pictuteLocation: null,
        verifyStatus: 0,
      };

      callback(null, user);
    }
  } catch (error) {
    if (isTransactionBegun) {
      await dbConnection.rollback();
    }
    callback(error);
  }
};

module.exports.createLocalUser = async function (
  username,
  password,
  email,
  firstname,
  lastname,
  contact,
  callback
) {
  try {
    await dbConnection.beginTransaction();

    const sqlCreateUser =
      "INSERT INTO users (email, fname, lname, contact, role, verify_status) " +
      "VALUES (?, ?, ?, ?, 'user', 0)";
    let [rows] = await dbConnection.query(sqlCreateUser, [
      email,
      firstname,
      lastname,
      contact,
    ]);
    let id = rows.insertId;

    const sqlAssignProvider =
      "INSERT INTO users_oauth (user_id, username, provider) " +
      "VALUES (?, ?, 'local')";
    await dbConnection.query(sqlAssignProvider, [id, username]);

    const sqlAssignPassword =
      "INSERT INTO users_password (user_id, password) " + "VALUES (?, ?)";
    await dbConnection.query(sqlAssignPassword, [id, password]);

    await dbConnection.commit();

    let user = {
      id: id,
      email: email,
      role: "user",
      firstName: firstname,
      lastName: lastname,
      contact: contact,
      pictuteLocation: null,
      verifyStatus: 0,
    };

    callback(null, user);
  } catch (error) {
    await dbConnection.rollback();
    callback(error);
  }
};

module.exports.findUser = async function (id, callback) {
  try {
    const sqlFindUser =
      "SELECT id, email, role, fname, lname, contact, picture_location, verify_status " +
      "FROM users " +
      "WHERE id = ? LIMIT 1";

    let [rows] = await dbConnection.execute(sqlFindUser, [id]);

    if (rows && rows.length != 0) {
      let user = {
        id: rows[0].id,
        email: rows[0].email,
        role: rows[0].role,
        firstName: rows[0].fname,
        lastName: rows[0].lname,
        contact: rows[0].contact,
        pictuteLocation: rows[0].picture_location,
        verifyStatus: rows[0].verify_status,
      };
      callback(null, user);
    } else {
      callback(null);
    }
  } catch (error) {
    callback(error);
  }
};
