const mysql = require("mysql2/promise");

// const options = {
//   host: "localhost",
//   user: "vendeece_admin",
//   password: "~H$;(FD&^2A+",
//   database: "vendeece_main",
// };

const options = {
  host: "localhost",
  user: "root",
  password: "1234",
  database: "vendeece_main",
};

module.exports = (async function () {
  let conn = await mysql.createConnection(options);
  return conn;
})();
