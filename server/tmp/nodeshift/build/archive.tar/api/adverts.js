let dbConnection = null;
(async function () {
  dbConnection = await require("../db/connection");
})();

module.exports.findAll = async function (data) {
  try {
    let dataFlat = [];

    let sqlFindAdverts =
      "SELECT a.id, a.title, " +
      "JSON_OBJECT('fname', u.fname, 'lname', u.lname) AS seller, " +
      "a.price, c.name AS category, d.name AS district " +
      "FROM adverts a, categories c, districts d, users u " +
      "WHERE a.district_id = d.id AND a.category_id = c.id AND a.user_id = u.id ";

    if (data.query && data.query.length != 0) {
      sqlFindAdverts = sqlFindAdverts.concat("AND (");
      data.query
        .trim()
        .split(" ")
        .forEach(function (word) {
          if (word.length != 0) {
            dataFlat.push("%" + word.toLowerCase() + "%");
            sqlFindAdverts += "LOWER(title) LIKE ? OR ";
          }
        });
      sqlFindAdverts = sqlFindAdverts
        .substring(0, sqlFindAdverts.length - 4)
        .concat(") ");
    }

    if (data.district && data.district.length != 0) {
      dataFlat.push(data.district);
      sqlFindAdverts = sqlFindAdverts.concat("AND district_id = ? ");
    }

    if (data.category && data.category.length != 0) {
      dataFlat.push(data.category);
      sqlFindAdverts = sqlFindAdverts.concat("AND category_id = ? ");
    }

    sqlFindAdverts = sqlFindAdverts.trim();

    let [rows] = await dbConnection.execute(sqlFindAdverts, dataFlat);
    if (rows && rows.length != 0) {
      return rows;
    } else {
      throw "Error: No Results.";
    }
  } catch (error) {
    console.log(error);
    return false;
  }
};

module.exports.find = async function (data) {
  try {
    let sqlFindAdverts =
      "SELECT a.title, a.price, a.description, c.name as category, d.name as district, " +
      "JSON_OBJECT('fname', u.fname, 'lname', u.lname, 'email', u.email, 'contact', u.contact) AS seller " +
      "FROM adverts a, categories c, districts d, users u " +
      "WHERE a.district_id = d.id AND a.category_id = c.id AND a.user_id = u.id AND a.id = ? " +
      "LIMIT 1";
    let [rows] = await dbConnection.execute(sqlFindAdverts, [data.id]);
    if (rows && rows.length != 0) {
      return rows[0];
    } else {
      throw "Error: No Results.";
    }
  } catch (error) {
    console.log(error);
    return false;
  }
};

module.exports.add = async function (data) {
  try {
    let sqlAddAdvert =
      "INSERT INTO adverts " +
      "(title, description, price, user_id, category_id, district_id) " +
      "VALUES (?, ?, ?, ?, ?, ?)";

    await dbConnection.execute(sqlAddAdvert, [
      data.title,
      data.description,
      data.price,
      data.userId,
      data.categoryId,
      data.districtId,
    ]);

    return true;
  } catch (error) {
    console.log(error);
    return false;
  }
};
