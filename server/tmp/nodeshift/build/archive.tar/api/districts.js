let dbConnection = null;
(async function () {
  dbConnection = await require("../db/connection");
})();

module.exports.findAllSummary = async function () {
  try {
    const sqlFindDistricts = "SELECT id, name FROM districts";
    let [rows] = await dbConnection.execute(sqlFindDistricts);
    if (rows && rows.length != 0) {
      return rows;
    } else {
      throw "Error: No Results.";
    }
  } catch (error) {
    console.log(error);
    return false;
  }
};

module.exports.findAll = async function () {
  try {
    const sqlFindDistricts =
      "SELECT d.id, d.name, COUNT(a.id) AS count " +
      "FROM districts d LEFT JOIN adverts a ON a.district_id = d.id " +
      "GROUP BY d.id";
    let [rows] = await dbConnection.execute(sqlFindDistricts);
    if (rows && rows.length != 0) {
      return rows;
    } else {
      throw "Error: No Results.";
    }
  } catch (error) {
    console.log(error);
    return false;
  }
};
