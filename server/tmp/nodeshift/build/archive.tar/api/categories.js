let dbConnection = null;
(async function () {
  dbConnection = await require("../db/connection");
})();

module.exports.findAllSummary = async function () {
  try {
    const sqlFindCategories = "SELECT id, name FROM categories";
    let [rows] = await dbConnection.execute(sqlFindCategories);
    if (rows && rows.length != 0) {
      return rows;
    } else {
      throw "Error: No Results.";
    }
  } catch (error) {
    console.log(error);
    return false;
  }
};

module.exports.findAll = async function () {
  try {
    const sqlFindCategories =
      "SELECT c.id, c.name, COUNT(a.id) AS count, c.description " +
      "FROM categories c LEFT JOIN adverts a ON a.category_id = c.id " +
      "GROUP BY id";
    let [rows] = await dbConnection.execute(sqlFindCategories);
    if (rows && rows.length != 0) {
      return rows;
    } else {
      throw "Error: No Results.";
    }
  } catch (error) {
    console.log(error);
    return false;
  }
};
