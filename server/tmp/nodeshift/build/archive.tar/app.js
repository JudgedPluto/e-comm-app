const express = require("express");
const bodyParser = require("body-parser");

const passport = require("passport");
const LocalStrategy = require("passport-local").Strategy;
const FacebookStratergy = require("passport-facebook").Strategy;
const GoogleStratergy = require("passport-google-oauth2").Strategy;

const authConfig = require("./auth/config");
const users = require("./auth/users");

const districts = require("./api/districts");
const categories = require("./api/categories");
const adverts = require("./api/adverts");

passport.use(
  new LocalStrategy(function (username, password, callback) {
    users.findLocalUser(username, password, function (err, user) {
      return callback(err, user);
    });
  })
);

passport.use(
  new FacebookStratergy(authConfig.facebook, function (
    accessToken,
    refreshToken,
    profile,
    callback
  ) {
    users.findOAuthUser(profile, "facebook", function (err, user) {
      return callback(err, user);
    });
  })
);

passport.use(
  new GoogleStratergy(authConfig.google, function (
    accessToken,
    refreshToken,
    profile,
    callback
  ) {
    users.findOAuthUser(profile, "google", function (err, user) {
      return callback(err, user);
    });
  })
);

passport.serializeUser(function (user, callback) {
  callback(null, user.id);
});

passport.deserializeUser(function (id, callback) {
  users.findUser(id, function (err, user) {
    callback(err, user);
  });
});

const app = express();

app.use(express.static("views"));

app.use(bodyParser.urlencoded({ extended: true }));

app.use(
  require("express-session")({
    secret: "vendee ceylon secret",
    resave: false,
    saveUninitialized: false,
  })
);

app.use(passport.initialize());
app.use(passport.session());

let authRoute = express.Router();
let apiRoute = express.Router();

// Non-AJAX - Done
authRoute.post(
  "/login",
  passport.authenticate("local", {
    successRedirect: "/",
    failureRedirect: "/login",
  })
);

// Non-AJAX - Done
authRoute.get("/logout", function (req, res) {
  req.logout();
  res.redirect("/");
});

// AJAX - Done
authRoute.get("/user", function (req, res) {
  res.send({
    authenticated: req.isAuthenticated(),
    user: req.isAuthenticated() ? req.user : "",
  });
});

// Non-AJAX - Done
authRoute.get(
  "/facebook",
  passport.authenticate("facebook", { scope: ["email"] })
);

// Non-AJAX - Done
authRoute.get(
  "/facebook/callback",
  passport.authenticate("facebook", {
    successRedirect: "/",
    failureRedirect: "/login",
  })
);

// Non-AJAX - Done
authRoute.get(
  "/google",
  passport.authenticate("google", {
    scope: [
      "https://www.googleapis.com/auth/userinfo.profile",
      "https://www.googleapis.com/auth/userinfo.email",
    ],
  })
);

// Non-AJAX - Done
authRoute.get(
  "/google/callback",
  passport.authenticate("google", {
    successRedirect: "/",
    failureRedirect: "/login",
  })
);

// Non-AJAX - Done
authRoute.post("/register", function (req, res, next) {
  let params = req.body;
  users.createLocalUser(
    params.username,
    params.password,
    params.email,
    params.firstname,
    params.lastname,
    params.contact,
    function (err, user) {
      if (err) {
        return next(err);
      } else {
        return req.login(user, function (error) {
          if (error) {
            return next(error);
          } else {
            return res.redirect("/");
          }
        });
      }
    }
  );
});

// AJAX - Done
apiRoute.get("/categories", async function (req, res) {
  let result = false;
  if (parseInt(req.query.summary)) {
    result = await categories.findAllSummary();
  } else {
    result = await categories.findAll();
  }
  res.send(result);
});

// AJAX - Done
apiRoute.get("/districts", async function (req, res) {
  let result = false;
  if (parseInt(req.query.summary)) {
    result = await districts.findAllSummary();
  } else {
    result = await districts.findAll();
  }
  res.send(result);
});

// AJAX - Done
apiRoute.get("/adverts", async function (req, res) {
  let result = await adverts.findAll(req.query);
  res.send(result);
});

// AJAX - Done
apiRoute.get("/adverts/item", async function (req, res) {
  let result = await adverts.find(req.query);
  res.send(result);
});

// Non-AJAX - Done
apiRoute.post("/adverts", async function (req, res) {
  let result = await adverts.add(req.body);
  if (result) {
    res.redirect("/");
  } else {
    res.redirect("/item/add");
  }
});

app.use("/api/auth", authRoute);
app.use("/api", apiRoute);

app.get("*", function (req, res) {
  res.sendFile("views/index.html", { root: __dirname });
});

let server_port = process.env.OPENSHIFT_NODEJS_PORT || 8080;

let server_ip_address = process.env.OPENSHIFT_NODEJS_IP || "127.0.0.1";

app.listen(server_port, server_ip_address, function () {
  console.log(
    "Server Listening on " + server_ip_address + ", port " + server_port
  );
});
